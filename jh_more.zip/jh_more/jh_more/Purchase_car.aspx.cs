﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

namespace jh_more
{
    public partial class Purchase_car : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string ConnStr = System.Configuration.ConfigurationManager.ConnectionStrings["listConnectionString"].ToString();

            string sql = "select * from shop_list where id = " + Request["card_id"].ToString();

            SqlConnection conn = new SqlConnection(ConnStr);
            conn.Open();

            SqlCommand comm = new SqlCommand(sql, conn);

            SqlDataReader dr = comm.ExecuteReader();

            if (dr.Read())
            {
                Label1.Text = dr["name"].ToString();
                Label2.Text = dr["price"].ToString();
                Label3.Text = dr["price"].ToString();
                Label4.Text = dr["price"].ToString();
                Label5.Text = dr["price"].ToString();
                Image1.ImageUrl = "imgs/" + dr["img"].ToString();
            }

            conn.Close();
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string ConnStr = System.Configuration.ConfigurationManager.ConnectionStrings["listConnectionString"].ToString(); 
            String sql = "insert into car(cname,cprice,amount,sum,ctime) values ('" + Label1.Text + "','" + Label2.Text + "','" + Label6.Text + "','" + Label3.Text + "','" + DateTime.Now.ToString() + "')";
            SqlConnection conn = new SqlConnection(ConnStr);


            conn.Open();
            SqlCommand sqlcmd = new SqlCommand(sql, conn);//构造一个sql命令

            sqlcmd.ExecuteNonQuery();

            

            //关闭数据库
            conn.Close();
            //Response.Write("ok");
        }
    }
}