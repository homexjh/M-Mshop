﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

namespace jh_more.admin
{
    public partial class Addaccount : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string ConnStr = System.Configuration.ConfigurationManager.ConnectionStrings["listConnectionString"].ToString();
            //插入数据
            String sql = "insert into [user] (username,password) values ('" + TextBox1.Text + "','" + TextBox2.Text + "')";
            SqlConnection conn = new SqlConnection(ConnStr);
            conn.Open();
            SqlCommand sqlcmd = new SqlCommand(sql, conn);//构造一个sql命令



            sqlcmd.ExecuteNonQuery();
            //关闭数据库
            conn.Close();
        }
    }
}