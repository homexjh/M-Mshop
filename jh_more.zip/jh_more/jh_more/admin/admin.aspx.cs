﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net;
using System.Data.SqlClient;

namespace jh_more.admin
{
    public partial class admin12 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string name = Dns.GetHostName();
            IPAddress[] ipadrlist = Dns.GetHostAddresses(name);
            Label1.Text = ipadrlist[0].ToString();
            Label2.Text = DateTime.Now.ToString();
            string ConnStr = System.Configuration.ConfigurationManager.ConnectionStrings["listConnectionString"].ToString();
            //插入数据
            String sql = "insert into record (ipAdress,loginTime) values ('" + Label1.Text + "','" + Label2.Text + "')";
            SqlConnection conn = new SqlConnection(ConnStr);
            conn.Open();
            SqlCommand sqlcmd = new SqlCommand(sql, conn);//构造一个sql命令



            sqlcmd.ExecuteNonQuery();
            //关闭数据库
            conn.Close();
        }
    }
}