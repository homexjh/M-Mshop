﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

namespace jh_more.admin
{
    public partial class adminProductUpdate : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string ConnStr = System.Configuration.ConfigurationManager.ConnectionStrings["listConnectionString"].ToString();

            string sql = "select * from shop_list where id = " + Request["id"].ToString();

            SqlConnection conn = new SqlConnection(ConnStr);
            conn.Open();

            SqlCommand comm = new SqlCommand(sql, conn);

            SqlDataReader dr = comm.ExecuteReader();
            if (dr.Read())
            {
                TextBox1.Text = dr["name"].ToString();
                TextBox2.Text = dr["price"].ToString();
                TextBox3.Text = dr["loca"].ToString();

                Image1.ImageUrl = "../imgs/" + dr["img"].ToString();
            }

            conn.Close();
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            //关闭当前页面
            Response.Write("<script>window.close();</script>");
        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            //获取productimg,将图片上传到网站目录
            string upFn = FileUpload1.PostedFile.FileName;
            //"D:\\temp\\1.jgp
            int strL = upFn.LastIndexOf("\\");
            //获取用户的图片名称1.jgp
            string imgfilename = upFn.Substring(strL + 1);
            Response.Write(imgfilename);
            //上传图片
            string path = Server.MapPath("../imgs/") + imgfilename;
            //Response.Write(path);
            FileUpload1.SaveAs(path);



            //连接数据库
            string ConnStr = System.Configuration.ConfigurationManager.ConnectionStrings["listConnectionString"].ToString();
            //构造sql语句
            String sql = "Update shop_list set img = '" + FileUpload1.PostedFile.FileName.Substring(strL + 1) + "' ,name = '" + TextBox4.Text + "',price =  '" + TextBox5.Text + "', loca = '" + TextBox6.Text + "'" +
                " where id =" + Request["id"].ToString();
            SqlConnection conn = new SqlConnection(ConnStr);
            conn.Open();

            SqlCommand comm = new SqlCommand(sql, conn);
            //comm.ExecuteNonQuery();
            if (comm.ExecuteNonQuery() > 0)
            {
                Response.Redirect("adminProductEdit.aspx");  //跳转到主页面
            }
            else
            {
                Response.Write("<script>alert('更新失败')</script>");
            }

            //关闭数据库
            conn.Close();
        }
    }
}