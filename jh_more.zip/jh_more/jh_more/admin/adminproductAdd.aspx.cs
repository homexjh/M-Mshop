﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

namespace jh_more.admin
{
    public partial class adminproductAdd : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            //关闭当前页面
            Response.Write("<script>window.close();</script>");
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
             //获取productimg,将图片上传到网站目录
            string upFn = FileUpload1.PostedFile.FileName;
            //"D:\\temp\\1.jgp
            int strL = upFn.LastIndexOf("\\");
            //获取用户的图片名称1.jgp
           string imgfilename = upFn.Substring(strL + 1);
           Response.Write(imgfilename);
            //上传图片
            string path = Server.MapPath("../imgs/") + imgfilename;
            //Response.Write(path);
            FileUpload1.SaveAs(path);
            //链接数据库
            //1、读取webconfig文件中的数据库链接字符串
            //2、构造connection去连接数据库
            string ConnStr = System.Configuration.ConfigurationManager.ConnectionStrings["listConnectionString"].ToString();
            String sql = "insert into shop_list(img,name,detail,loca,price) values ('" + FileUpload1.PostedFile.FileName.Substring(strL + 1) + "','" + TextBox1.Text + "','" + TextBox3.Text + "','" + TextBox4.Text + "','" + TextBox2.Text + "')";
            SqlConnection conn = new SqlConnection(ConnStr);
           

            conn.Open();


            //对数据库进行插入操作


            //String sql = "insert into shop_list (name,detail,loca) values ('" + TextBox1.Text + "','" + TextBox2.Text + "','" + TextBox3.Text + "')";
            

            SqlCommand sqlcmd = new SqlCommand(sql, conn);//构造一个sql命令

           
            
            if(sqlcmd.ExecuteNonQuery() > 0)
            {
                Response.Redirect("adminproductEdit.aspx");
            }
            else
            {
                Response.Write("插入失败");
            }

            //关闭数据库
            conn.Close();
            //Response.Write("ok");
        
        }
    }
}