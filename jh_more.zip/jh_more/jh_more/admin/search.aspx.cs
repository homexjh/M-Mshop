﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

namespace jh_more.admin
{
    public partial class search : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
            string ConnStr = System.Configuration.ConfigurationManager.ConnectionStrings["listConnectionString"].ToString();
            //string sql = "select * from shop_list where name = " + Request["pname"].ToString();
            //string sql = "select * from shop_list where name = " + Session["name"];
            //select * from shop_list where name = '苹果';
            string sql = "select * from shop_list where name = '苹果'";

            SqlConnection conn = new SqlConnection(ConnStr);
            conn.Open();

            SqlCommand comm = new SqlCommand(sql, conn);

            SqlDataReader dr = comm.ExecuteReader();

            if (dr.Read())
            {
                TextBox1.Text = dr["name"].ToString();
                TextBox2.Text = dr["price"].ToString();
                TextBox3.Text = dr["loca"].ToString();
                Image1.ImageUrl = "../imgs/" + dr["img"].ToString();
            }

            conn.Close();
        }
    }
}