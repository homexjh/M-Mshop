// $('.nav_left>ul .list_mnue').click(function (e) {
//     console.log(e);
//     $(this).children('.list_mnue').slideDown().end().siblings().children('.list_mnue').slideUp();
// });
$('.nav_left>ul>li').click(function (e) {
    console.log(e);
    $(this).children('.list_mnue').slideDown().end().siblings().children('.list_mnue').slideUp();
    $(this).addClass('clickColor').siblings().removeClass('clickColor');
    // $(this).children('.title').css("background-color","#00a5a5").siblings().removeClass('title');
    //2.箭头旋转
    //2.箭头旋转
    $('.nav_title>.arrow').css({
        'transform':'rotate(0deg)'
    });

    $(this).find('.arrow').css({
        'transform':'rotate(90deg)'
    });
})