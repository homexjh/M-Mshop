window.addEventListener('load', function (ev) {
    /*----------------1.轮播图---------------------*/


    /*----------------2.倒计时---------------------*/
    (function () {
        // 1. 获取倒计时标签
        var sKillTime = myTool.$('s_kill_time');
        var spans = sKillTime.children;

        // 2. 设置定时器
        var time = 8 * 60 * 60, hour, min, second;
        var timerId = setInterval(function () {
            // 2.1 时间--
            time--;
            // 2.2 倒计时结束
            if(time <= 0){
                clearInterval(timerId)
            }
            // 2.3 拆分时分秒
            hour = Math.floor(time/ (60 * 60)); // 08 09 10 11
            min = Math.floor(time % (60 * 60) / 60);
            second = Math.floor(time % 60);

            // 2.4 把内容显示在span标签
            spans[1].innerText = size(hour);
            spans[3].innerText = size(min);
            spans[5].innerText = size(second);
        }, 1000);

        function size(num) {
            return num < 10 ? '0' + num : num;
        }
    })()
});