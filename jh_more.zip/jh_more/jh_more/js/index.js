    //个人二维码的显示与隐藏
    //获取标签
    var e_coder = document.getElementById('e_coder');
    console.log(e_coder);
    var  e_app = document.getElementById('e_app');
    console.log(e_app);


    //鼠标进入事件
    e_coder.onmouseover = function (ev) {
        //1.改变背景图片
        this.style.background = 'url("imgs/e_coder_selected.png") no-repeat';
        //2.显示隐藏的二维码
        e_app.style.display = 'block';
    }
    //鼠标离开事件
    e_coder.onmouseout = function (ev) {
        //1.恢复原来的背景图片
        this.style.background = 'url("imgs/e_coder_normal.png") no-repeat';
        //2.隐藏二维码
        e_app.style.display = 'none';
    }

    //大屏轮播
    var $oBanner = $('.banner');
    var $aLis = $('.banner ul li');
    var $oLeft = $('.banner .left');
    var $oRight = $('.banner .right');
    var $aDots = $('.banner .dots li');
    console.log($oBanner);
    console.log($aLis);
    console.log($oLeft);
    console.log($oRight);
    console.log($aDots);
    var timer = null;
    var showIndex = 0;

    function play() {
        // clearInterval(timer);
        showIndex = showIndex % $aLis.length;
        $aLis.eq(showIndex).stop().fadeIn(500).siblings().fadeOut(1000);
        $aDots.eq(showIndex).addClass('active').siblings().removeClass('active');
    }

    function autoplay() {
        clearInterval(timer);
        timer = setInterval(function () {
            showIndex++;
            play();
        },2000)
    }

    autoplay();

    $oBanner.hover(function () {
        clearInterval(timer);
    },function () {
        autoplay();
    })

    $oLeft.click(function (event) {
        showIndex--;
        play();
    })

    $oRight.click(function (event) {
        showIndex++;
        play();
    })

    $aDots.click(function (event) {
        let index = $(this).index();
        showIndex = index;
        $aLis.eq(showIndex).stop().fadeIn(500).siblings().fadeOut(1000);;
        $aDots.eq(showIndex).addClass('active').siblings().removeClass('active');
    })

