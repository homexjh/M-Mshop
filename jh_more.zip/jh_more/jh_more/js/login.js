//获取标签
var $allA = $('.content-header a');
// console.log($allA);
var $allDom = $('.content-body .dom');
// console.log($allDom);
//遍历
for (var i = 0; i<$allA.length; i++) {
    var a = $allA[i];
    // console.log(a);
    (function (i) {
        a.onclick = function (ev) {
            //1.清除同级别的选中样式类
            for (var j = 0; j<$allA.length;j++) {
                $allA[j].className = 's';
                $allDom[j].style.display = 'none';
            }

            //设置当前的a标签选中样式
            this.className = 'current';
            $allDom[i].style.display = 'block'
        }
    })(i)
}