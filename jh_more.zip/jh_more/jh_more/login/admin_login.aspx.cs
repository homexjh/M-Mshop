﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

namespace jh_more.login
{
    public partial class admin_login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            string ConnStr = System.Configuration.ConfigurationManager.ConnectionStrings["listConnectionString"].ToString();

            SqlConnection conn = new SqlConnection(ConnStr);

            conn.Open();

            string sql = "select * from [user] where username='" + logphone.Text + "' and password='" + logpwd.Text + "'";
            SqlCommand comm = new SqlCommand(sql, conn);//表示要对 SQL Server 数据库执行bai的一个 Transact-SQL 语句或存储过du程

            SqlDataReader dr = comm.ExecuteReader();
            if (dr.Read())
            {
                Session["user"] = logphone.Text;
                Response.Redirect("../admin/DataEcharts.aspx");
            }
            else
            {
                Response.Write("你的账号或者密码有误");
            }
        }
    }
}