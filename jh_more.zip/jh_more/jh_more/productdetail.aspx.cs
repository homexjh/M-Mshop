﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

namespace jh_more
{
    public partial class productdetail : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string ConnStr = System.Configuration.ConfigurationManager.ConnectionStrings["listConnectionString"].ToString();
            string sql = "select * from shop_list where id = " + Request["productid"].ToString();

            SqlConnection conn = new SqlConnection(ConnStr);
            conn.Open();

            SqlCommand comm = new SqlCommand(sql, conn);

            SqlDataReader dr = comm.ExecuteReader();

            if (dr.Read())
            {
                Label1.Text = dr["name"].ToString();
                Label2.Text = dr["desc"].ToString();
                Label3.Text = dr["detail"].ToString();
                Label4.Text = dr["loca"].ToString();
                Label5.Text = dr["price"].ToString();
                Label6.Text = dr["id"].ToString();
                Image1.ImageUrl = "imgs/" + dr["img"].ToString();
            }

            conn.Close();

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            int card_id = 2;
            string id = Request["productid"].ToString();
           // string sql = "select * from shop_list where id = " + Request["productid"].ToString();
            Response.Redirect("Purchase_car.aspx?card_id="+id);
            
        }
    }
}